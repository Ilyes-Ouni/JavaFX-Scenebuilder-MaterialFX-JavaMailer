package com.example.scenebuilderproject;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.io.File;
import java.util.Optional;

public class HelloController {
    @FXML
    private Label welcomeText;
    @FXML
    private ImageView imageView;
    @FXML
    protected void onHelloButtonClick() {
        welcomeText.setText("Welcome to JavaFX Application!");
    }

    @FXML
    private TextField tnom;

    @FXML
    private TextField tpoids;

    @FXML
    private TextField ttaille;

    @FXML
    private RadioButton br1;

    @FXML
    private RadioButton br2;

    @FXML
    private CheckBox cb1;

    @FXML
    private CheckBox cb2;

    @FXML
    private CheckBox cb3;

    @FXML
    private CheckBox cb4;

    @FXML
    private CheckBox cb5;

    public void initialize() {
        File file = new File("/Users/ilyes/OneDrive/Desktop/download.jpeg");
        Image image = new Image(file.toURI().toString());
        imageView.setImage(image);
    }

    @FXML
    void Calcul(ActionEvent event){
        if (!this.tnom.getText().isEmpty() && !this.tpoids.getText().isEmpty() && !this.ttaille.getText().isEmpty() && (this.br1.isSelected() ^ this.br2.isSelected()) &&
                (this.cb1.isSelected() || this.cb2.isSelected() || this.cb3.isSelected() || this.cb4.isSelected() || this.cb5.isSelected())){
            try {
                float poids = Float.parseFloat(this.tpoids.getText());
                float taille = Float.parseFloat(this.ttaille.getText());
                float imc = poids / (taille * taille);

                Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle("Succès");
                alert.setHeaderText("IMC calculé avec succès.");
                alert.setContentText("Le IMC pour " + this.tnom.getText() + " est: " + imc);
                alert.show();
            }catch (NumberFormatException e){
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Form Error");
                alert.show();
            }
        }else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Form Error");
            alert.show();
        }
    }

    @FXML
    void Quitter(ActionEvent event) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Quit");
        alert.setHeaderText("Voulez-vous quitter l'application ?");
        ButtonType okButton = new ButtonType("OK", ButtonBar.ButtonData.YES);
        ButtonType cancelButton = new ButtonType("Cancel", ButtonBar.ButtonData.CANCEL_CLOSE);
        alert.getButtonTypes().setAll(okButton, cancelButton);
        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == okButton){
            System.exit(0);
        }
    }

}