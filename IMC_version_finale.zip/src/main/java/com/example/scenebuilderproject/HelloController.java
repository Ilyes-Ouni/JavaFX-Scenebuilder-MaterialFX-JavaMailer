package com.example.scenebuilderproject;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.io.File;
import java.util.Optional;

public class HelloController {
    @FXML
    private Label welcomeText;
    @FXML
    private ImageView imageView;
    @FXML
    protected void onHelloButtonClick() {
        welcomeText.setText("Welcome to JavaFX Application!");
    }

    @FXML
    private TextField tnom;

    @FXML
    private TextField tpoids;

    @FXML
    private TextField ttaille;

    @FXML
    private RadioButton br1;

    @FXML
    private RadioButton br2;

    @FXML
    private CheckBox cb1;

    @FXML
    private CheckBox cb2;

    @FXML
    private CheckBox cb3;

    @FXML
    private CheckBox cb4;

    public void initialize() {
        File file = new File("/Users/ilyes/OneDrive/Desktop/download.jpeg");
        Image image = new Image(file.toURI().toString());
        imageView.setImage(image);
    }

    @FXML
    void Calcul(ActionEvent event){
        if (!this.tnom.getText().isEmpty() && !this.tpoids.getText().isEmpty() && !this.ttaille.getText().isEmpty() && (this.br1.isSelected() ^ this.br2.isSelected())){
            try {
                float poids = Float.parseFloat(this.tpoids.getText());
                float taille = Float.parseFloat(this.ttaille.getText());
                float imc = poids / (taille * taille);

                Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle("Succès");
                alert.setHeaderText("IMC calculé avec succès.");

                String sexe = "";
                if (br1.isSelected()) {
                    sexe = "homme";
                } else if (br2.isSelected()) {
                    sexe = "femme";
                }

                String activite = "";
                if (cb1.isSelected()) {
                    activite += "sportive, ";
                }
                if (cb2.isSelected()) {
                    activite += "sédentaire, ";
                }
                if (cb3.isSelected()) {
                    activite += "modérée, ";
                }
                if (cb4.isSelected()) {
                    activite += "intense, ";
                }

                if (activite.isEmpty()) {
                    activite = "n'a pas d'activité";
                }

                String resultat = "";
                if (imc < 18.5) {
                    resultat = "Insuffisance pondérale";
                } else if (imc < 25) {
                    resultat = "Normal";
                } else if (imc < 30) {
                    resultat = "Surpoids";
                } else if (imc >= 30) {
                    resultat = "Obésité";
                }

                alert.setContentText("Nom: " + this.tnom.getText() + "`\nSexe: " + sexe + "\nActivite: " + activite + "\nIMC: " + imc + "\nStatus: " + resultat );

                alert.show();
            }catch (NumberFormatException e){
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Form Error");
                alert.show();
            }
        }else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Form Error");
            alert.show();
        }
    }

    @FXML
    void Quitter(ActionEvent event) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Quitter");
        alert.setHeaderText("Voulez-vous quitter l'application ?");
        ButtonType okButton = new ButtonType("Confirmer", ButtonBar.ButtonData.YES);
        ButtonType cancelButton = new ButtonType("Annuler", ButtonBar.ButtonData.CANCEL_CLOSE);
        alert.getButtonTypes().setAll(okButton, cancelButton);
        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == okButton){
            System.exit(0);
        }
    }

}